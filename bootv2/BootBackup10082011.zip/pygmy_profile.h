// This file is intended to be used as a template
// To use, copy into your project folder and:
// Add the board specific header ( if needed )
// Add any defines for your specific project 
// Include at the top of main.c

#pragma once

#include "pygmy_sys.h"
#include "pygmy_port.h"
#include "pygmy_com.h"
#include "pygmy_audio.h"
#include "pygmy_adc.h"
#include "pygmy_file.h"
#include "pygmy_lcd.h"
#include "pygmy_gui.h"
#include "pygmy_nvic.h"
#include "pygmy_rtc.h"
#include "pygmy_string.h"
#include "pygmy_web.h"

#include "profiles/pygmy_nebula.h"

//-------------------------------------------------------------------------------------
// Place any user defines below--------------------------------------------------------
//-------------------------------------------------------------------------------------


