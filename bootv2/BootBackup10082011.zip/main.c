/**************************************************************************
    PygmyOS ( Pygmy Operating System ) - BootLoader
    Copyright (C) 2011  Warren D Greenway

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
***************************************************************************/

#include "pygmy_profile.h"
#include "pygmy_fpec.h"


#define __DIV(__PCLK, __BAUD)       ((__PCLK*25)/(4*__BAUD))
#define __DIVMANT(__PCLK, __BAUD)   (__DIV(__PCLK, __BAUD)/100)
#define __DIVFRAQ(__PCLK, __BAUD)   (((__DIV(__PCLK, __BAUD) - (__DIVMANT(__PCLK, __BAUD) * 100)) * 16 + 50) / 100)
#define __USART_BRR(__PCLK, __BAUD) ((__DIVMANT(__PCLK, __BAUD) << 4)|(__DIVFRAQ(__PCLK, __BAUD) & 0x0F))
#define VECT_TAB_OFFSET  0x1000
//#define FLASH_BASE       ((u32)0x08000000)

#define XMODEM_ACK          0x06
#define XMODEM_NACK         0x15
#define XMODEM_EOT          0x04
//#define XMODEM_SOH          0x01
#define XMODEM_CAN          0x18
#define XMODEM_NEXT         0x00
#define XMODEM_LAST         0x01
#define XMODEM_RECV         BIT1
#define XMODEM_MODE_SOH     BIT2
#define XMODEM_SEND         BIT3
#define XMODEM_SEND_WAIT    BIT4
#define XMODEM_SEND_EOT     BIT5
#define BOOT_CANCEL         BIT7
//#define BOOT_ERROR          BIT6

//generateBaud( u32 uiClock, u32 uiRate );
u8 bootTest( void );
void bootTestAndLoad( void );
void bootBootOS( void );

void putBufferUSART3( u16 uiLen, u8 *ucBuffer );
void putcUSART3( u8 ucChar );
void putstr( u8 *ucBuffer );
void putIntUSART3( u32 ulData );
u8 xmodemWritePacket( u8 *ucBuffer );
void xmodemSendPacket( u8 ucLast );
u8 cmdHandler( u8 ucByte );

u8 cmdErase( u8 *ucParams );
u8 cmdFormat( u8 *ucParams );
u8 cmdRecv( u8 *ucParams );
u8 cmdSend( u8 *ucParams );
u8 cmdRead( u8 *ucParams );
u8 cmdRm( u8 *ucParams );
u8 cmdLs( u8 *ucParams );
u8 cmdMv( u8 *ucParams );
u8 cmdBoot( u8 *ucParams );
u8 cmdFlash( u8 *ucParams );
u8 cmdReset( u8 *ucParams );
u8 cmdTest( u8 *ucParams );
//u8 cmdPeek( u8 *ucParams );
//u8 cmdPoke( u8 *ucParams );

u8 cmdNull( u8 *ucParams );

//u8 Pygmy_CMD_PickCommand( u8 *ucBuffer, PYGMYCMD *pygmyCommands );

const char BOOT_OK[] = "\rOK\r";
const char BOOT_ERROR[] = "\rERROR\r";

const char BOOT_filename[] = "boot.hex";
const char BOOT_greeting[] = "\r\rPygmyOS Loader V1\r+ cancels boot\r\r> ";

const PYGMYCMD BOOTCOMMANDS[] = {   {(u8*)"erase", cmdErase},
                                    {(u8*)"format", cmdFormat},
                                    {(u8*)"recv", cmdRecv},
                                    {(u8*)"send", cmdSend},
                                    {(u8*)"read", cmdRead},
                                    {(u8*)"rm", cmdRm},
                                    {(u8*)"ls", cmdLs},
                                    {(u8*)"mv", cmdMv},
                                    {(u8*)"boot", cmdBoot},
                                    {(u8*)"flash", cmdFlash},
                                    {(u8*)"reset", cmdReset},
                                    //{(u8*)"peek", cmdPeek},
                                    //{(u8*)"poke", cmdPoke},
                                    {(u8*)"test", cmdTest},
                                    {(u8*)"", cmdNull} // No Commands after NULL
                                    }; 

PYGMYFILE pygmyFile;
u32 globalFileLen, globalXMTimeout, globalTransaction, globalXMCount;
volatile u32 globalBootTimeout;
volatile u8 globalStatus = 0, globalBootStatus = 0;//, globalBootStatus = BOOT_CANCEL;

int main( void )
{    
    // First Init the Clocks
        PYGMY_RCC_HSE_ENABLE;
        while( !PYGMY_RCC_HSE_READY );
        // The following PLL Multiplier * XTAL must not exceed 24MHz for 100 Series MCU 
        RCC->CFGR2 = 0;
        RCC->CFGR = BIT15|BIT14|BIT16|BIT1;
        PYGMY_RCC_PLL_ENABLE;
        while( !PYGMY_RCC_PLL_READY );
        // HSI Must be ON for Flash Program/Erase Operations
        PYGMY_RCC_HSI_ENABLE;
        //RCC->CFGR |= HSION;
    // End Clock Init 

    // Configure Interrupts
        PYGMY_WATCHDOG_UNLOCK;
        PYGMY_WATCHDOG_PRESCALER( IWDT_PREDIV128 );
        PYGMY_WATCHDOG_TIMER( 0x0FFF );
        PYGMY_WATCHDOG_START;
        PYGMY_WATCHDOG_REFRESH;
        //Pygmy_NVIC_Enable( USART3_IRQ );
        NVIC->ISER[ 1 ] = 0x00000001 <<  7 ;
        SYSTICK->LOAD = 48000; // Based on  ( 2X the System Clock ) / 1000
        SYSTICK->VAL = 48000;
        SYSTICK->CTRL = 0x07;   // Enable system timer
        
   
    // End Configure Interrupts

    // Basic Port Init
       
        //RCC->APB2ENR |= (IOPAEN|IOPBEN|IOPCEN|AFIOEN);
        //RCC->APB2ENR |= (IOPAEN|IOPBEN|IOPCEN);
        RCC->APB2ENR |= (RCC_IOPBEN|RCC_IOPCEN|RCC_IOPAEN);
        PYGMY_RCC_USART3_ENABLE;
        //GPIOC->CRH &= ~(PIN10_CLEAR|PIN9_CLEAR|PIN8_CLEAR); GPIOC->CRH |= (PIN10_OUT50_GPPUSHPULL|PIN9_OUT50_GPPUSHPULL|PIN8_IN_FLOAT);
        /*GPIOC->CRH &= ~PIN12_CLEAR;
        GPIOC->CRH |= PIN12_OUT50_GPPUSHPULL;
        GPIOC->ODR |= BIT12;
        GPIOC->CRH &= ~PIN8_CLEAR; 
        GPIOC->CRH |= PIN8_OUT50_GPPUSHPULL; 
        GPIOC->ODR |= BIT8;
        GPIOC->CRH &= ~PIN11_CLEAR; 
        GPIOC->CRH |= PIN11_OUT50_GPPUSHPULL;
        GPIOC->CRH &= ~PIN9_CLEAR; 
        GPIOC->CRH |= PIN9_OUT50_GPPUSHPULL;
        GPIOC->CRH &= ~PIN10_CLEAR; 
        GPIOC->CRH |= PIN10_IN_FLOAT;*/
        RF24_CS_INIT;
        SRAM_CS_INIT;
        FLASH_CS_INIT;
        SPI_SCK_INIT;
        SPI_MISO_INIT;
        SPI_MOSI_INIT;
       
        
    // End Basic Port Init
        GPIOB->CRH &= ~( PIN10_CLEAR | PIN11_CLEAR );
        GPIOB->CRH |= ( PIN10_OUT50_ALTPUSHPULL | PIN11_IN_FLOAT );
        USART3->BRR = generateBaud( 24000000, 230400 ); 
        USART3->CR3 |= USART_ONEBITE;
        USART3->CR1 = ( USART_OVER8 | USART_UE | USART_RXNEIE | USART_TE | USART_RE  );
    // USART3 Init, PB10 TXD, PB11 RXD, Reserved for RS232 Debug connector
       
    // End USART3 Init
        
    // Note: SST FLASH ICs must have write-protection removed by formatting before use
    
    mountRoot();
    putstr( (u8*)BOOT_greeting );
        
    
    // First allow 2 seconds for receipt of '+' char 
    // If received, cancel download sequence and wait for commands
    // Timeout is incremented every millisecond by SysTick
    for( globalBootTimeout = 0; globalBootTimeout < 2000; ){
        ;
    }
    if( !(globalBootStatus & BOOT_CANCEL) ){
        bootBootOS();   
    }
    while( 1 ){
        // Wait for commands
    }
}


u16 generateBaud( u32 uiClock, u32 uiRate )
{
    // USARTDIV = DIV_Mantissa + (DIV_Fraction / 8 � (2 � OVER8))
    u16 uiBRR;
    /*u32 uiBRR, uiMantisa, uiFraction;
    
    uiBRR       = ( uiClock * 25 ) / ( uiRate * 4 );
    uiMantisa   = uiBRR / 100;
    uiFraction  = uiBRR - ( ( ( ( uiMantisa * 100 ) * 16 ) + 50 ) / 100 );
    //uiBRR       = ( uiMantisa << 4 ) | ( uiFraction & 0x00000007 );
    uiBRR       = ( uiMantisa << 4 ) | ( ( uiFraction / 8 ) & 0x0000000F );
*/

    uiBRR = ( ( (uiClock >> 3 ) / uiRate ) << 4 ) + ( ( ( uiClock / uiRate ) ) & 0x0007 );

    return( (u16)uiBRR ); 
}

u8 bootTest( void )
{
    // This function pre-tests every row in firmware file for corruption before erase and program
    u32 i;
    u8 ucBuffer[ 64 ], ucCalculatedSum, *ucSubString;

    if( !fileOpen( &pygmyFile, (u8*)BOOT_filename, READ ) ){
        putstr( "\rNo boot.hex" );
        return( 0 );
    }
 
    for( ; !( pygmyFile.Attributes & EOF ); ){
        // Get an IHEX packet
        for( i = 0; i < 64; i++ ){
            ucBuffer[ i ] = fileGetChar( &pygmyFile );
            if( ucBuffer[ i ] == '\r' ){
                ucBuffer[ i ] = '\0';
                break;
            } // if
        } // for
        //ucSubString = Pygmy_STRING_small_GetNextSubString( ucBuffer );
        ucSubString = getNextSubString( ucBuffer, WHITESPACE|NEWLINE );
        if( *(ucSubString++) != ':' ){
            putstr( (u8*)BOOT_ERROR );
            return( 0 );
        } // if
        // Following works because the output cannot be longer than the input being converted
        convertHexEncodedStringToBuffer( ucSubString, ucSubString );
        if( ucSubString[ 3 ] == IHEX_EOF ){
            break; // We have reached EOF without error
        }
        for( i = 0, ucCalculatedSum = 0; i < ucSubString[ 0 ]+4; i++ ){
            ucCalculatedSum += ucSubString[ i ];
        } // for
        ucCalculatedSum = 1 + ( 0xFF ^ (u8)ucCalculatedSum ); 
        if( (u8)ucCalculatedSum != ucSubString[ i ] ){ // Last short is checksum
            putstr( (u8*)BOOT_ERROR );
            return( 0 ); // Corrupt HEX Row
        } // if
        i = ( (u16)ucSubString[ 1 ] << 8 ) + ucSubString[ 2 ];
        if( ucSubString[ 3 ] == IHEX_DATA && i < 0x2000 ){
            putstr( (u8*)BOOT_ERROR );
            return( 0 );
        } // if 
    } // for

    return( 1 );
}

void bootTestAndLoad( void )
{
    u32 i;
    u8 ucBuffer[ 64 ], ucStatus, *ucSubString;

    putstr( "\rProgramming" );
    
    if( fileOpen( &pygmyFile, (u8*)BOOT_filename, READ ) ){ // If file boot.hex exists then load
        fpecUnlock();
        if ( !fpecEraseProgramMemory( 8 ) ){ // Always erase all pages before attempting a write
            putstr( (u8*)BOOT_ERROR );
            return;
        } // if

        for( ucStatus = 0; !( pygmyFile.Attributes & EOF ) && ucStatus != 0xFF; ){
            for( i = 0; i < 64; i++ ){
                ucBuffer[ i ] = fileGetChar( &pygmyFile );
                if( ucBuffer[ i ] == '\r' ){
                    ucBuffer[ i ] = '\0';
                    ucSubString = getNextSubString( (u8*)ucBuffer, WHITESPACE|NEWLINE );
                    // Add 1 to pointer before passing to skip the ':' packet start char
                    fpecProcessIHEX( (u8*)( ucSubString + 1 ) );
                    break; // Time to fetch next IHEX entry
                } // if
            } // for
        } // for
    } // if
    
}

void bootBootOS( void )
{
    PYGMYVOIDPTR pygmyMain;
    u32 *ulOS;
    
    putstr( "\rBooting..." );
    ulOS = (u32*)0x08002004; // Address is start vector table + 4 bytes
    pygmyMain = (PYGMYVOIDPTR)*ulOS;
    if ( *ulOS != 0xFFFFFFFF ){
        RCC->CIR = 0x009F0000;
        SCB->VTOR = ((u32)0x08002000 & (u32)0x1FFFFF80);//FLASH_BASE | VECT_TAB_OFFSET;
        pygmyMain(); // pass control to Pygmy OS
    } // if
    putstr( "\rNo OS\r> " );
} 

void putBufferUSART3( u16 uiLen, u8 *ucBuffer )
{
    u16 i;

    for( i = 0; i < uiLen ; i++ ){
        putcUSART3( ucBuffer[ i ] ) ;
    }    
}

void putIntUSART3( u32 ulData )
{
    s32 i, iMagnitude, iValue;

    for( i = 0, iMagnitude = 1; ( iMagnitude * 10 ) <= ulData; i++ )
        iMagnitude *= 10;
    
    for( ; i >= 0; i-- ){
        iValue = ulData / iMagnitude;
        putcUSART3( 48 + iValue ); // 48 = '0' in ASCII
        ulData -= ( iValue * iMagnitude );
        iMagnitude /= 10;
    }
    
}

void putcUSART3( u8 ucChar )
{
    while( !( USART3->SR & USART_TXE ) );
    USART3->DR = ucChar; 
}

void putstr( u8 *ucBuffer )
{ 
    for( ; *ucBuffer ; ){
        putcUSART3( *(ucBuffer++) );
    }
}

void USART3_IRQHandler( void )
{
    static u8 ucBuffer[ 256 ], ucIndex = 0;
    //u16 i, uiID;
    u8 ucByte;//, *ucSubString;//, *ucParam1;

    if( USART3->SR & USART_RXNE ) { 
        USART3->SR &= ~USART_RXNE;
        ucByte = USART3->DR ;
    
        if( globalStatus & XMODEM_RECV ){ // RECV      
            if( globalStatus & XMODEM_MODE_SOH ){ // Recieving Payload, after <SOH>
                ucBuffer[ ucIndex++ ] = ucByte;
                if( ucIndex == 131 ){
                    globalStatus &= ~XMODEM_MODE_SOH; // Reset Packet Marker
                    if( globalXMCount == ucBuffer[ 0 ] && 
                        xmodemWritePacket( (u8*)(ucBuffer+2) ) ) { // Returns 1 if check sum correct, 0 if not
                        if( globalXMCount + 1 == 256 )
                            globalXMCount = 0;
                        else
                            ++globalXMCount;
                        putcUSART3( 0x06 );// Return ACK
                    } else{
                        /*if( globalXMCount != ucBuffer[ 0 ] ){
                            ucBuffer[ 0 ] = globalXMCount;
                            ucBuffer[ 1 ] ='X';
                        }
                        Pygmy_FILE_PutBuffer( &pygmyFile, 128, ucBuffer );*/
                        putcUSART3( 0x15 );// Return NACK
                    }  
                } 
            } else{
                if( ucByte == 0x01 ){ // This is XModem <SOH>
                    globalStatus |= XMODEM_MODE_SOH; // Set Packet Marker
                    globalXMTimeout = 1000;
                    globalTransaction = 60;
                } else if( ucByte == 0x04 ){ // 0x04 Marks End Of Transmission              
                    globalStatus &= ~( XMODEM_RECV );
                    filePutBuffer( &pygmyFile, 128, ucBuffer );
                    fileClose( &pygmyFile );
                    putcUSART3( 0x06 ); // Send Ack to close connection
                    putstr( "Done\r> " );
                } 
                
                ucIndex = 0;
            }
        } else if( globalStatus & XMODEM_SEND ){ // SEND
            if( ucByte == XMODEM_ACK ){
                if( globalStatus & XMODEM_SEND_EOT ){
                    globalStatus &= ~( XMODEM_SEND_EOT|XMODEM_SEND);
                    putstr( (u8*)BOOT_OK );
                    return;
                }
                globalXMTimeout = 1000;
                globalTransaction = 10;
                if( pygmyFile.Attributes & EOF ){
                    globalStatus |= XMODEM_SEND_EOT;
                    putcUSART3( XMODEM_EOT );
                } else{
                    ++globalXMCount;
                    xmodemSendPacket( XMODEM_NEXT ); // 0 = next pack
                }
            } else if( ucByte == XMODEM_NACK ){
                globalXMTimeout = 1000;
                globalTransaction = 10;
                if( globalStatus & XMODEM_SEND_WAIT ){
                    xmodemSendPacket( XMODEM_NEXT ); // 1 = next, in this case this is first
                    globalStatus &= ~XMODEM_SEND_WAIT;
                } else{
                    xmodemSendPacket( XMODEM_LAST ); // 0 = next pack
                }
            } 
        
        } else if( ucByte == '\r' || ( ucByte == '+' && !( globalBootStatus & BOOT_CANCEL ) ) ){
            
            ucBuffer[ ucIndex ] = '\0'; // Add NULL to terminate string
            ucIndex = 0;
            if( ucByte == '+' ){
                putstr( "\rBoot Canceled\r> " );
                globalBootStatus |= BOOT_CANCEL;
                return;
            } 
            //if( Pygmy_CMD_PickCommand( ucBuffer, BOOTCOMMANDS ) ){
            if( executeCmd( ucBuffer, BOOTCOMMANDS ) ){
                putstr( "\r> " );
            } else{
                putstr( "\rERROR\r> " );
            } // else
        } else{
             
            putcUSART3( ucByte );
            if( ucByte == '\b'  ){
                if( ucIndex ){
                    --ucIndex;
                }
            } else {//if( ucByte == '\b' ){//&& ucIndex ){ // Recieved backspace, rollback index
                ucBuffer[ ucIndex++ ] = ucByte;
            }
        }

    }
   
}

u8 xmodemWritePacket( u8 *ucBuffer )
{
    u8 i, ucSum;

    // count ( 0-1 before calling this function ) must be validated by calling function 
    // 0-127 are data bytes, 128 is checksum 
    ucSum = ucBuffer[ 0 ];
    for( i = 1; i < 128; i++ ){
        ucSum += ucBuffer[ i ]; 
    }    
    if( ucSum == ucBuffer[ 128 ] ){
        filePutBuffer( &pygmyFile, 128, ucBuffer );
 
        return( 1 );
    }
    return( 0 );
}

void xmodemSendPacket( u8 ucLast )
{
    static u8 ucBuffer[ 132 ];
    u8 i, ucSum;
    
    if( !ucLast ){ // If not resend then make a new packet
        ucBuffer[ 0 ] = 0x01; // <SOH>
        ucBuffer[ 1 ] = globalXMCount; // Packet Count
        ucBuffer[ 2 ] = 0xFF - globalXMCount; // Ones Complement of Count
        for( ucSum = 0, i = 3; i < 131; i++ ){ // 128 bytes payload
            ucBuffer[ i ] = fileGetChar( &pygmyFile );
            ucSum += ucBuffer[ i ];
        }
        ucBuffer[ i ] = ucSum; // add the check sum as the final bytes    
    }
    
    putBufferUSART3( 132, ucBuffer );
}

void SysTick_Handler( void )
{   
    PYGMY_WATCHDOG_REFRESH;
    ++globalBootTimeout;

    if( globalStatus & XMODEM_RECV ){
        if( globalXMTimeout )
            --globalXMTimeout;
        else{
            putcUSART3( XMODEM_NACK );
            globalXMTimeout = 1000;
            if( globalTransaction )
                --globalTransaction;
            else{
                globalStatus &= ~(XMODEM_RECV|XMODEM_MODE_SOH);
                putstr( "XM Timeout\r> " );
            } // lse
        } // else
    } else if( globalStatus & XMODEM_SEND ){
        if( globalXMTimeout )
            --globalXMTimeout;
        else{
            xmodemSendPacket( XMODEM_LAST );
            globalXMTimeout = 1000;
            if( globalTransaction )
                --globalTransaction;
            else{
                globalStatus &= ~(XMODEM_SEND|XMODEM_SEND_EOT);
                putstr( (u8*)BOOT_ERROR );
            } // else
        } // else
    } // else if
    
}

u8 cmdErase( u8 *ucParams )
{
    fpecUnlock();
    fpecEraseProgramMemory( 8 );
    globalStatus |= BIT0; // Mark main memory as erased

    return( 1 );
}

u8 cmdFormat( u8 *ucParams )
{
    format( "" );

    return( 1 );
}

u8 cmdRecv( u8 *ucParams )
{
    u8 *ucSubString;
    
    ucSubString = getNextSubString( ucParams, WHITESPACE|NEWLINE );
    if( fileOpen( &pygmyFile, ucSubString, WRITE ) ){
        globalStatus |= BIT1;       // BIT1 used to mark In XModem Status
        globalXMTimeout = 1000; // 10 seconds
        globalTransaction = 60;
        globalXMCount = 1;
        return( 1 );
    } 
        
    return( 0 );
}

u8 cmdSend( u8 *ucParams )
{
    u8 *ucSubString;
    
    ucSubString = getNextSubString( ucParams, WHITESPACE|NEWLINE );
    if( fileOpen( &pygmyFile, ucSubString, READ ) ){
        globalXMCount = 1;
        globalXMTimeout = 1000;
        globalTransaction = 10;
        globalStatus |= ( XMODEM_SEND | XMODEM_SEND_WAIT ); 
        
        return( 1 );
     } // if
 
    return( 0 );
}

u8 cmdRead( u8 *ucParams )
{
    u16 i;
    u8 *ucSubString, ucChar;
    
    ucSubString = getNextSubString( ucParams, WHITESPACE|NEWLINE );
    if( ucSubString && fileOpen( &pygmyFile, ucSubString, READ ) ){
        for( i = 0; !(pygmyFile.Attributes & EOF ); i++ ){
            ucChar = fileGetChar( &pygmyFile );
            if( !(pygmyFile.Attributes & EOF ) ){
                if( ucChar == '\r' ){
                    i = 0;
                } // if
                if( !( i % 80 ) ){
                    putcUSART3( '\r' );
                } // if
                if( ucChar != '\r' && ( ucChar < 32 || ucChar > 126 ) ){
                    putcUSART3( '(' );
                    putIntUSART3( ucChar );
                    putcUSART3( ')' );
                } else{
                    putcUSART3( ucChar );
                }
            } // if
        } // 
        return( 1 );
    } // if

    return( 0 );
}

u8 cmdRm( u8 *ucParams )
{   
    return( fileDelete( getNextSubString( ucParams, WHITESPACE|NEWLINE ) ) );

    return( 0 );
}

u8 cmdLs( u8 *ucParams )
{
    u16 i, uiID;
  
    for( i = 0; i < pygmyRootVolume.MaxFiles; i++ ){
        uiID = getFileName( i, pygmyFile.Name );
        if( uiID ){
            putcUSART3( '\r' );
            putstr( pygmyFile.Name );
            putcUSART3( '\t' );
            putIntUSART3( getFileLength( uiID ) );
        } // if
    } // for
    putstr( "\rFree:\t\t" );
    putIntUSART3( getFreeSpace() );
    putcUSART3( '\r' );

    return( 1 );
}

u8 cmdMv( u8 *ucParams )
{
    //u8 *ucSubString1, *ucSubString2;

    //ucSubString1 = getNextSubString( ucParams, WHITESPACE|NEWLINE );
    //ucSubString2 = getNextSubString( "", WHITESPACE|NEWLINE );

    //if( ucSubString1 && ucSubString2 ){
    return( fileRename( getNextSubString( ucParams, WHITESPACE|NEWLINE ), getNextSubString( "", WHITESPACE|NEWLINE ) ) );
    //} // if

    //return( 0 );
}

u8 cmdReset( u8 *ucParams )
{
    PYGMY_RESET;

    // No return after reset
}

u8 cmdBoot( u8 *ucParams )
{
    if( bootTest() ){
        bootTestAndLoad();
    } // if
    PYGMY_RESET;
    
    // No return after reset
}

u8 cmdFlash( u8 *ucParams )
{
    if( bootTest() ){
        bootTestAndLoad();
    } // if

    return( 1 );
}

/*u8 cmdPeek( u8 *ucParams )
{
    u16 i, uiLen;
    u8 *ulAddress;
    u8 *ucSubString1, *ucSubString2;
    
    
    ucSubString1 = getNextSubString( ucParams, WHITESPACE|NEWLINE );
    ucSubString2 = getNextSubString( "", WHITESPACE|NEWLINE );
    
    if( ucSubString1 ){
        if( ucSubString2 ){
            uiLen = convertStringToInt( ucSubString2 );
        } else{
            uiLen = 0;
        } // else
        ulAddress = (u8*)convertStringToInt( ucSubString1 );
        for( i = 0; i < uiLen; i++ ){
            if( !(i % 16 ) ){
                putcUSART3( '\r' );
            } else{
                putcUSART3( ' ' );
            } // else
            //SIZEREG->Pages
            putIntUSART3( (u8)*( ulAddress + i ) );
        } // for
        return( 1 );
    } // if

    return( 0 );
}*/

/*u8 cmdPoke( u8 *ucParams )
{
    u8 *ulAddress;
    u8 *ucSubString1, *ucSubString2;
    
    ucSubString1 = getNextSubString( ucParams, WHITESPACE|NEWLINE );
    ucSubString2 = getNextSubString( "", WHITESPACE|NEWLINE );
    if(ucSubString1 && ucSubString2 ){
        ulAddress = (u8*)convertStringToInt( ucSubString1 );
        *ulAddress = (u8)convertStringToInt( ucSubString2 );
        return( 1 );
    }

    return( 0 );
}*/

u8 cmdTest( u8 *ucParams )
{
    // The first file entry is the storage descriptor which is formatted as follows:
    //    [ NAME 13B ][ ATTRIB B ][ SECTORS 2B ][ SECTORSIZE 2B ][ MAXFILES 4B ][ MEDIALEN 4B ]
    // The second file entry is the table pointers, which is formatted as follows
    //    [ FATPERSECTOR 2B ][ FILESSECTORS 2B ][ FATSECTORS 2B ][ FIRSTFILESECTOR 4B ][ FILES_A 4B ][ FILES_B 4B ][ FAT_A 4B ][ FAT_B 4B ] 
   // putstr( "\rAttr: " );
    //putIntUSART3( flashReadByte( PYGMY_FILE_VOLUME_FIELD_ATTRIB ) );
    //putstr( "\rSec: " );
    putIntUSART3( flashReadWord( PYGMY_FILE_VOLUME_FIELD_SECTORS ) );
    //putstr( "\rFiles: " );
    putIntUSART3( flashReadLong( PYGMY_FILE_VOLUME_FIELD_MAXFILES ) );
    //putstr( "\rCap: " );
    putIntUSART3( flashReadLong( PYGMY_FILE_VOLUME_FIELD_MEDIASIZE ) );
    //putstr( "\rFAT: " );
    putIntUSART3( flashReadWord( PYGMY_FILE_VOLUME_FIELD_ENTRIESPERFAT ) );
    //putstr( "\rFSec: " );
    putIntUSART3( flashReadWord( PYGMY_FILE_VOLUME_FIELD_FILESSECTORS ) );
    //putstr( "\rFATSec: " );
    putIntUSART3( flashReadWord( PYGMY_FILE_VOLUME_FIELD_FATSECTORS ) );
    //putstr( "\rFirstFSec: " );
    putIntUSART3( flashReadLong( PYGMY_FILE_VOLUME_FIELD_FIRSTFILESECTOR ) );
    //putstr( "\rFilesA: " );
    putIntUSART3( flashReadLong( PYGMY_FILE_VOLUME_FIELD_FILES_A ) );
    //putstr( "\rFilesB: " );
    putIntUSART3( flashReadLong( PYGMY_FILE_VOLUME_FIELD_FILES_B ) );
    //putstr( "\rFATA: " );
    putIntUSART3( flashReadLong( PYGMY_FILE_VOLUME_FIELD_FAT_A ) );
    //putstr( "\rFATB: " );
    putIntUSART3( flashReadLong( PYGMY_FILE_VOLUME_FIELD_FAT_B ) );
    //putstr( "\r" );
    
    return( 1 );
}

u8 cmdNull( u8 *ucParams )
{
    return( 0 );
}

u8 executeCmd( u8 *ucBuffer, PYGMYCMD *pygmyCommands )
{
    u16 i;
    u8 *ucCommand;
    
    ucCommand = getNextSubString( ucBuffer, WHITESPACE | PUNCT );
    if( !ucCommand )
        return( 0 );
        
    for( i = 0; 1; i++ ){ 
        if( isStringSame( "", pygmyCommands[ i ].Name ) ){
            return( 0 );
        }
        if( isStringSame( ucCommand, pygmyCommands[ i ].Name ) ){
            if( pygmyCommands[ i ].Call( "" ) ){
                return( 1 );
            }else{
                return( 0 );
            } // else
        }// if
    } // for

    return( 0 );
}

